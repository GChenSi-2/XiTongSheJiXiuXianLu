"""
Grade a candidate's submission against the challenge metadata.
Usage:
    python check_submission.py <challenge_output/> <submission.txt>
"""
import json
import sys
from pathlib import Path
from validator import validate


def grade(metadata_path: Path, submission_path: Path):
    meta = json.loads(metadata_path.read_text())
    submission = submission_path.read_text().strip().upper()
    # Strip everything that isn't ACGT (tolerate fasta headers, whitespace, etc.)
    submission = ''.join(c for c in submission if c in 'ACGT')

    print(f"Submission length:  {len(submission)} nt")
    print(f"Expected length:    {3 * (meta['protein_length'] + 1)} nt (incl. stop)")
    print("")

    is_valid, violations, score = validate(submission, meta["protein"], verbose=True)
    print("")
    print(f"Result: {'PASS' if is_valid else 'FAIL'} on hard constraints")

    if is_valid:
        threshold = meta["pass_threshold_cai"]
        baseline = meta["baseline_cai"]
        print(f"Achieved CAI:        {score:.4f}")
        print(f"Pass threshold:      {threshold:.4f}")
        print(f"Solver baseline CAI: {baseline:.4f}")
        if score >= threshold:
            margin = (score - threshold) / threshold * 100
            print(f"VERDICT: PASS (+{margin:.1f}% over threshold)")
        else:
            shortfall = (threshold - score) / threshold * 100
            print(f"VERDICT: VALID BUT BELOW THRESHOLD (-{shortfall:.1f}%)")
    else:
        print(f"VERDICT: FAIL ({len(violations)} hard-constraint violation(s))")

    return is_valid and score >= meta["pass_threshold_cai"]


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    d = Path(sys.argv[1])
    grade(d / "metadata.json", Path(sys.argv[2]))
