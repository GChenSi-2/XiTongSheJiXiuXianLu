# Codon Optimization Challenge

A complete challenge-generation and grading pipeline for testing LLM
performance on multi-constraint codon optimization — a real industrial
problem from synthetic biology / biologics manufacturing.

## What this challenge tests

The LLM must produce a synthetic DNA coding sequence that:

1. Translates exactly to a target protein
2. Avoids 8 common restriction enzyme sites
3. Stays within a global GC band (45-60%)
4. Stays within a per-window GC band (every 50nt: 30-70%)
5. Has no homopolymer runs ≥ 6 nt
6. Achieves CAI ≥ 0.75 for E. coli K12
7. Has 5' RNA folding ΔG ≥ -10 kcal/mol (weak structure for translation initiation)
8. **Maximizes CAI** subject to (1)-(7)

Why this is hard for an LLM:

- Search space is ~6^N (with N = 100 codons → 10^77 sequences)
- Constraints conflict: high CAI → high GC at 5' → too-stable structure
- "Naive smart answer" (pick highest-frequency codon per position) passes
  6/7 constraints and looks plausible, but fails the 5' folding constraint.
- Solving it properly requires implementing an actual algorithm
  (simulated annealing, ILP, constraint programming) and *running it*.

## Files

```
codon_table.py          E. coli K12 codon usage + CAI weights
validator.py            All hard-constraint checks + composite score
solver.py               Simulated-annealing ground-truth solver
generate_challenge.py   End-to-end pipeline: produces challenge_output/
check_submission.py     Grades a candidate's submission

challenge_output/
  PROBLEM.md            What you send to the LLM (or human)
  metadata.json         Baseline + thresholds (kept private)
  naive_submission.txt  Example "smart but wrong" answer (greedy CAI)
  solver_submission.txt Reference answer from SA solver (passes)
```

## How to use

### 1. Generate a challenge

```bash
python generate_challenge.py
# → creates challenge_output/{PROBLEM.md, metadata.json}
# → solver takes ~3 min for 100-aa protein
```

### 2. Send PROBLEM.md to your LLM

Copy the contents of `challenge_output/PROBLEM.md` as the user message.
Save the LLM's response as a `.txt` file containing only the DNA sequence.

### 3. Grade the submission

```bash
python check_submission.py challenge_output/ llm_answer.txt
```

The grader reports per-constraint PASS/FAIL and the final CAI vs threshold.

## How to extend (this is the methodology you'll iterate)

### Generate variant problems

- **Different proteins**: swap `TARGET_PROTEIN` in `generate_challenge.py`.
  Use synthetic but realistic sequences to avoid training-data contamination.
- **Different organisms**: replace `ECOLI_K12_FREQ` in `codon_table.py`
  with another codon usage table (human, CHO, S. cerevisiae). Each organism
  shifts the optimal CAI/GC trade-off differently.
- **Different lengths**: 50 aa = trivial; 100 aa = current; 300+ aa = very hard.

### Make it harder (each adds a difficulty notch)

- Add a **restriction site whitelist** at specific positions (cloning context).
- Forbid more motifs (CpG islands, Shine-Dalgarno-like sequences).
- Constrain **codon pair bias** (CPB) to natural distribution.
- Add a **CpG dinucleotide ceiling** (relevant for mammalian expression).
- Add **mRNA structure constraints** at 3' end (decay signals).
- Require **avoiding cryptic splice sites** for mammalian hosts.
- Add **uridine depletion** constraint (mRNA vaccine relevant: pseudouridine
  context, reduces innate immunogenicity).
- Constrain **MFE of entire CDS** to a narrow band.

### Make it easier (if your LLM under test is weaker)

- Drop the 5' structure constraint (this is the main "trap").
- Relax GC window constraints.
- Lower the pass threshold (e.g., 0.85 instead of 0.95).

## Submission rubric for Mindrift-style platform

A polished problem submission would include:

1. **PROBLEM.md** — the verbatim text shown to the model.
2. **Worked solution** — your reference DNA + the CAI/dG/GC values it achieves.
3. **Solver code** — what you used to verify the answer is reachable.
4. **Failure modes** — at least 2 plausible LLM answers that fail, with
   diagnosis. (`naive_submission.txt` is one example.)
5. **Difficulty justification** — why this problem cannot be solved by
   pattern-matching from training data and requires algorithmic execution.

## Notes on biological realism

- E. coli K12 codon usage is from the standard MG1655 reference; values are
  reproducible against any public table.
- CAI definition is Sharp & Li 1987 (geometric mean of relative adaptiveness),
  excluding single-codon AAs (Met, Trp).
- 5'-folding constraint at -10 kcal/mol over 60nt is in line with the
  empirical relationship between 5'-mRNA structure and translation efficiency
  reported by Kudla et al. (2009).
- All restriction sites are 6-cutters used in routine cloning. Adjust list
  per real cloning vector.

## Known limitations

- `seqfold` is a pure-Python nearest-neighbor RNA folding implementation.
  For publication-grade evaluation, use ViennaRNA's `RNAfold` instead. The
  validator can be swapped with a one-line edit.
- The current solver is single-temperature SA. For larger proteins, replace
  with parallel tempering or ILP (Gurobi/CBC formulation).
- Reverse-strand restriction site detection is omitted; a real grader should
  check both strands (1-line addition to `validator.py`).
