"""
E. coli K12 codon usage table (frequencies per amino acid).
Reference: Sharpe & Li 1987 with updated K12 MG1655 counts.
CAI weights = freq_codon / max(freq_synonymous).
"""
from collections import defaultdict
from math import log, exp

# E. coli K12 codon frequencies (per thousand codons)
ECOLI_K12_FREQ = {
    'F': {'TTT': 22.3, 'TTC': 16.0},
    'L': {'TTA': 13.9, 'TTG': 13.7, 'CTT': 11.9, 'CTC': 10.5, 'CTA':  3.9, 'CTG': 52.6},
    'I': {'ATT': 30.4, 'ATC': 25.1, 'ATA':  4.4},
    'M': {'ATG': 27.5},
    'V': {'GTT': 18.3, 'GTC': 15.3, 'GTA': 10.9, 'GTG': 26.4},
    'S': {'TCT':  8.5, 'TCC':  8.6, 'TCA':  7.1, 'TCG':  8.9, 'AGT':  8.8, 'AGC': 16.1},
    'P': {'CCT':  7.0, 'CCC':  5.5, 'CCA':  8.4, 'CCG': 23.2},
    'T': {'ACT':  8.9, 'ACC': 23.4, 'ACA':  7.1, 'ACG': 14.5},
    'A': {'GCT': 15.5, 'GCC': 25.5, 'GCA': 20.3, 'GCG': 33.7},
    'Y': {'TAT': 16.2, 'TAC': 12.2},
    'H': {'CAT': 12.9, 'CAC':  9.7},
    'Q': {'CAA': 15.3, 'CAG': 29.0},
    'N': {'AAT': 17.7, 'AAC': 21.6},
    'K': {'AAA': 33.6, 'AAG': 10.3},
    'D': {'GAT': 32.7, 'GAC': 19.2},
    'E': {'GAA': 39.1, 'GAG': 18.7},
    'C': {'TGT':  5.2, 'TGC':  6.4},
    'W': {'TGG': 13.9},
    'R': {'CGT': 20.0, 'CGC': 19.7, 'CGA':  3.8, 'CGG':  5.9, 'AGA':  3.6, 'AGG':  2.1},
    'G': {'GGT': 24.7, 'GGC': 29.6, 'GGA':  8.0, 'GGG': 11.1},
    '*': {'TAA':  1.9, 'TAG':  0.2, 'TGA':  1.0},
}

# CAI weights: w_i = freq_i / max_freq_in_synonymous_group
CAI_WEIGHTS = {}
for aa, codons in ECOLI_K12_FREQ.items():
    max_f = max(codons.values())
    for codon, f in codons.items():
        CAI_WEIGHTS[codon] = f / max_f

# Codon -> AA reverse map
CODON_TO_AA = {}
for aa, codons in ECOLI_K12_FREQ.items():
    for codon in codons:
        CODON_TO_AA[codon] = aa

# AA -> list of synonymous codons (sorted by frequency desc)
AA_TO_CODONS = {
    aa: sorted(c.keys(), key=lambda x: -c[x])
    for aa, c in ECOLI_K12_FREQ.items()
}


def cai(dna_seq: str) -> float:
    """Geometric mean of CAI weights, excluding Met/Trp (single-codon AAs)."""
    n = len(dna_seq) // 3
    log_sum = 0.0
    counted = 0
    for i in range(n):
        codon = dna_seq[i*3:(i+1)*3].upper()
        w = CAI_WEIGHTS.get(codon)
        if w is None or w == 0:
            return 0.0
        # Skip single-codon AAs (their w is always 1)
        if CODON_TO_AA[codon] in ('M', 'W'):
            continue
        log_sum += log(w)
        counted += 1
    return exp(log_sum / counted) if counted else 1.0


def translate(dna_seq: str) -> str:
    """Translate DNA to protein."""
    n = len(dna_seq) // 3
    return ''.join(CODON_TO_AA.get(dna_seq[i*3:(i+1)*3].upper(), '?') for i in range(n))


if __name__ == '__main__':
    # Quick sanity check
    print(f"Number of codons indexed: {len(CODON_TO_AA)}")
    print(f"CAI of 'ATGAAACTGGTT': {cai('ATGAAACTGGTT'):.3f}")
    print(f"Translation: {translate('ATGAAACTGGTT')}")
