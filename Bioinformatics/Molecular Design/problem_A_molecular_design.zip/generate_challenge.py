"""
Generate a complete challenge package: protein + constraints + baseline + grader.
The output (challenge.json) is what gets sent to the candidate (LLM or human).
"""
import json
import time
from pathlib import Path
from solver import solve
from validator import (
    RESTRICTION_SITES, GC_GLOBAL_MIN, GC_GLOBAL_MAX,
    GC_WINDOW_SIZE, GC_WINDOW_MIN, GC_WINDOW_MAX,
    HOMOPOLYMER_MAX, CAI_MIN, DG_5PRIME_WINDOW, DG_5PRIME_MIN,
)

# A 100-aa synthetic but realistic protein (composition matches E. coli avg).
# Not directly searchable in training data; substitute your own real protein here.
TARGET_PROTEIN = (
    "MKLVAILGSTDKFGRPVAITLNDQEYWHCSARLMNGTILDFKEAVPQRHWYIG"
    "SCMNDKLAVTRPEQHWYIGSCMNDKLAVTRPEQHWYIGSCMNDKLAV"
)


def build_problem_statement(protein: str, baseline_cai: float) -> str:
    """The exact problem text sent to the candidate."""
    return f"""# Codon Optimization Challenge (E. coli K12 expression)

You are given a target protein sequence. Your task: design a synthetic mRNA
coding sequence (DNA, T-only) that satisfies ALL hard constraints below and
maximizes the Codon Adaptation Index (CAI) for E. coli K12.

## Target protein ({len(protein)} aa)
{protein}

## Hard constraints (all must be satisfied)

1. **Translation**: The DNA must translate exactly to the target protein
   followed by a single stop codon. No synonymous deviations allowed.

2. **No restriction sites** (forward strand): {", ".join(RESTRICTION_SITES.keys())}.
   Motifs: {RESTRICTION_SITES}

3. **Global GC content**: {GC_GLOBAL_MIN*100:.0f}%-{GC_GLOBAL_MAX*100:.0f}% (inclusive).

4. **Sliding-window GC**: every {GC_WINDOW_SIZE}-nt window must have GC in
   [{GC_WINDOW_MIN*100:.0f}%, {GC_WINDOW_MAX*100:.0f}%].

5. **No homopolymer runs** of length ≥ {HOMOPOLYMER_MAX + 1} (i.e., no AAAAAA,
   TTTTTT, GGGGGG, CCCCCC).

6. **CAI ≥ {CAI_MIN}** computed against the E. coli K12 weight table
   (Sharp & Li 1987 method).

7. **5' folding energy ≥ {DG_5PRIME_MIN} kcal/mol**: the first {DG_5PRIME_WINDOW} nt
   (as RNA, T→U) must have minimum free energy ≥ {DG_5PRIME_MIN} kcal/mol at 37 °C.
   Use a standard nearest-neighbor model (e.g., seqfold or ViennaRNA).

## Objective

Maximize CAI subject to all constraints above. You must achieve
**CAI ≥ {baseline_cai:.4f}** to pass.

## Submission format

Return ONLY the final DNA sequence as a single uppercase string of
A/C/G/T (no spaces, no FASTA header, no commentary).
"""


def main():
    protein = TARGET_PROTEIN
    out_dir = Path("challenge_output")
    out_dir.mkdir(exist_ok=True)

    print(f"Generating challenge for {len(protein)}-aa protein...")
    print("Running ground-truth solver (this is the baseline LLM must beat)...")
    t0 = time.time()
    baseline_dna, baseline_cai = solve(protein, max_iters=8000, seed=42, verbose=False)
    elapsed = time.time() - t0

    if baseline_dna is None:
        raise RuntimeError("Solver failed to find any valid sequence")

    # Set the passing threshold slightly below the baseline so good answers count.
    # An LLM that finds something approaching this is impressive.
    pass_threshold = round(baseline_cai * 0.97, 4)

    problem_md = build_problem_statement(protein, pass_threshold)
    (out_dir / "PROBLEM.md").write_text(problem_md)

    metadata = {
        "protein": protein,
        "protein_length": len(protein),
        "baseline_dna": baseline_dna,
        "baseline_cai": round(baseline_cai, 4),
        "pass_threshold_cai": pass_threshold,
        "solver_iters": 8000,
        "solver_runtime_sec": round(elapsed, 1),
        "constraints": {
            "restriction_sites": list(RESTRICTION_SITES.keys()),
            "gc_global": [GC_GLOBAL_MIN, GC_GLOBAL_MAX],
            "gc_window_size": GC_WINDOW_SIZE,
            "gc_window_range": [GC_WINDOW_MIN, GC_WINDOW_MAX],
            "homopolymer_max": HOMOPOLYMER_MAX,
            "cai_min": CAI_MIN,
            "dg_5prime_window": DG_5PRIME_WINDOW,
            "dg_5prime_min": DG_5PRIME_MIN,
        },
    }
    (out_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))

    print(f"\n--- Challenge generated ---")
    print(f"  Protein length:        {len(protein)} aa")
    print(f"  Baseline CAI (solver): {baseline_cai:.4f}")
    print(f"  Pass threshold:        {pass_threshold:.4f}")
    print(f"  Solver runtime:        {elapsed:.1f}s")
    print(f"  Files written to:      {out_dir.resolve()}")


if __name__ == "__main__":
    main()
