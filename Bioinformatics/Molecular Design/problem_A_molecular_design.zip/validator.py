"""
Validator for the codon optimization challenge.
Returns: (is_valid: bool, violations: list, score: float)
"""
import re
from seqfold import dg
from codon_table import cai, translate, CODON_TO_AA

# Forbidden restriction sites (avoid these in the coding sequence)
RESTRICTION_SITES = {
    'EcoRI':   'GAATTC',
    'BamHI':   'GGATCC',
    'HindIII': 'AAGCTT',
    'XhoI':    'CTCGAG',
    'NdeI':    'CATATG',
    'NcoI':    'CCATGG',
    'SalI':    'GTCGAC',
    'NotI':    'GCGGCCGC',
}

# Hard constraint thresholds
GC_GLOBAL_MIN = 0.45
GC_GLOBAL_MAX = 0.60
GC_WINDOW_SIZE = 50
GC_WINDOW_MIN = 0.30
GC_WINDOW_MAX = 0.70
HOMOPOLYMER_MAX = 5            # no run of 6 or more identical bases
CAI_MIN = 0.75
DG_5PRIME_WINDOW = 60          # first N nt
DG_5PRIME_MIN = -10.0          # kcal/mol; folding must be ≥ this (weaker = higher = better)


def gc(seq: str) -> float:
    if not seq: return 0.0
    return (seq.count('G') + seq.count('C')) / len(seq)


def check_translation(dna: str, target_protein: str):
    """Sequence must translate exactly to target protein (with stop codon)."""
    if len(dna) % 3 != 0:
        return False, f"Length {len(dna)} not multiple of 3"
    translated = translate(dna)
    expected = target_protein + '*'
    if translated != expected:
        # Find first mismatch
        for i, (a, b) in enumerate(zip(translated, expected)):
            if a != b:
                return False, f"Position {i}: got {a}, expected {b}"
        return False, f"Length mismatch: got {len(translated)} aa, expected {len(expected)}"
    return True, None


def check_restriction_sites(dna: str):
    """Reject if any forbidden motif is present (forward strand only for simplicity)."""
    hits = []
    for name, motif in RESTRICTION_SITES.items():
        pos = dna.find(motif)
        if pos >= 0:
            hits.append(f"{name} ({motif}) at pos {pos}")
    return (len(hits) == 0), hits


def check_gc_global(dna: str):
    g = gc(dna)
    if g < GC_GLOBAL_MIN or g > GC_GLOBAL_MAX:
        return False, f"Global GC = {g:.3f}, must be in [{GC_GLOBAL_MIN}, {GC_GLOBAL_MAX}]"
    return True, None


def check_gc_windows(dna: str):
    """No sliding 50-nt window with GC < 30% or > 70%."""
    violations = []
    for i in range(len(dna) - GC_WINDOW_SIZE + 1):
        window = dna[i:i+GC_WINDOW_SIZE]
        g = gc(window)
        if g < GC_WINDOW_MIN or g > GC_WINDOW_MAX:
            violations.append(f"window [{i}, {i+GC_WINDOW_SIZE}): GC={g:.3f}")
    return (len(violations) == 0), violations[:3]  # cap output


def check_homopolymer(dna: str):
    """No run of (HOMOPOLYMER_MAX + 1) or more identical bases."""
    pattern = re.compile(r"(A{6,}|T{6,}|G{6,}|C{6,})")
    hits = [(m.group(), m.start()) for m in pattern.finditer(dna)]
    return (len(hits) == 0), hits[:5]


def check_cai(dna: str):
    c = cai(dna)
    if c < CAI_MIN:
        return False, f"CAI = {c:.3f}, must be ≥ {CAI_MIN}"
    return True, None


def check_5prime_structure(dna: str):
    """First DG_5PRIME_WINDOW nt should have weak secondary structure."""
    head = dna[:DG_5PRIME_WINDOW].replace('T', 'U')
    free_energy = dg(head, temp=37.0)
    if free_energy < DG_5PRIME_MIN:
        return False, f"5' dG = {free_energy:.2f} kcal/mol, must be ≥ {DG_5PRIME_MIN}"
    return True, f"5' dG = {free_energy:.2f}"


def composite_score(dna: str) -> float:
    """Score to maximize once all hard constraints pass."""
    return cai(dna)


def validate(dna: str, target_protein: str, verbose: bool = True):
    """Run all checks. Returns (is_valid, violations_list, score)."""
    dna = dna.upper().replace('U', 'T').replace(' ', '').replace('\n', '')

    checks = [
        ("Translation", check_translation(dna, target_protein)),
        ("Restriction sites", check_restriction_sites(dna)),
        ("Global GC", check_gc_global(dna)),
        ("GC windows", check_gc_windows(dna)),
        ("Homopolymer", check_homopolymer(dna)),
        ("CAI", check_cai(dna)),
        ("5' structure", check_5prime_structure(dna)),
    ]

    violations = []
    for name, (ok, info) in checks:
        status = "PASS" if ok else "FAIL"
        if verbose:
            print(f"  [{status}] {name}: {info if not ok else (info or 'ok')}")
        if not ok:
            violations.append((name, info))

    is_valid = (len(violations) == 0)
    score = composite_score(dna) if is_valid else 0.0
    return is_valid, violations, score


if __name__ == '__main__':
    # Manual sanity test
    test_dna = "ATG" + "AAA"*10 + "TAA"  # mostly homopolymer-failing
    validate(test_dna, "M" + "K"*10)
