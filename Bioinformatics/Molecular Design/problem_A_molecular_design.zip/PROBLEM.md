# Codon Optimization Challenge (E. coli K12 expression)

You are given a target protein sequence. Your task: design a synthetic mRNA
coding sequence (DNA, T-only) that satisfies ALL hard constraints below and
maximizes the Codon Adaptation Index (CAI) for E. coli K12.

## Target protein (100 aa)
MKLVAILGSTDKFGRPVAITLNDQEYWHCSARLMNGTILDFKEAVPQRHWYIGSCMNDKLAVTRPEQHWYIGSCMNDKLAVTRPEQHWYIGSCMNDKLAV

## Hard constraints (all must be satisfied)

1. **Translation**: The DNA must translate exactly to the target protein
   followed by a single stop codon. No synonymous deviations allowed.

2. **No restriction sites** (forward strand): EcoRI, BamHI, HindIII, XhoI, NdeI, NcoI, SalI, NotI.
   Motifs: {'EcoRI': 'GAATTC', 'BamHI': 'GGATCC', 'HindIII': 'AAGCTT', 'XhoI': 'CTCGAG', 'NdeI': 'CATATG', 'NcoI': 'CCATGG', 'SalI': 'GTCGAC', 'NotI': 'GCGGCCGC'}

3. **Global GC content**: 45%-60% (inclusive).

4. **Sliding-window GC**: every 50-nt window must have GC in
   [30%, 70%].

5. **No homopolymer runs** of length ≥ 6 (i.e., no AAAAAA,
   TTTTTT, GGGGGG, CCCCCC).

6. **CAI ≥ 0.75** computed against the E. coli K12 weight table
   (Sharp & Li 1987 method).

7. **5' folding energy ≥ -10.0 kcal/mol**: the first 60 nt
   (as RNA, T→U) must have minimum free energy ≥ -10.0 kcal/mol at 37 °C.
   Use a standard nearest-neighbor model (e.g., seqfold or ViennaRNA).

## Objective

Maximize CAI subject to all constraints above. You must achieve
**CAI ≥ 0.9499** to pass.

## Submission format

Return ONLY the final DNA sequence as a single uppercase string of
A/C/G/T (no spaces, no FASTA header, no commentary).
