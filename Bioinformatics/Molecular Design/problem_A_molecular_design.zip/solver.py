"""
Ground-truth solver: simulated annealing for codon optimization.
Used by the problem author to set a baseline score that the candidate must beat.
"""
import random
import re
import math
from seqfold import dg
from codon_table import AA_TO_CODONS, CODON_TO_AA, cai
from validator import (
    RESTRICTION_SITES, GC_WINDOW_SIZE, GC_WINDOW_MIN, GC_WINDOW_MAX,
    GC_GLOBAL_MIN, GC_GLOBAL_MAX, CAI_MIN, DG_5PRIME_WINDOW, DG_5PRIME_MIN,
    gc, validate,
)

HOMO_PATTERN = re.compile(r"(A{6,}|T{6,}|G{6,}|C{6,})")


def energy(dna: str, cache_5p_dg=None):
    """
    Lower energy = better. Returns (E, pen_only, cai_value, dg5).
    Sequence is VALID iff pen_only == 0.
    """
    n = len(dna)
    pen = 0.0

    for motif in RESTRICTION_SITES.values():
        pen += 100.0 * dna.count(motif)

    pen += 50.0 * len(HOMO_PATTERN.findall(dna))

    g = gc(dna)
    if g < GC_GLOBAL_MIN:
        pen += 200.0 * (GC_GLOBAL_MIN - g)
    elif g > GC_GLOBAL_MAX:
        pen += 200.0 * (g - GC_GLOBAL_MAX)

    win_viol = 0
    for i in range(0, n - GC_WINDOW_SIZE + 1, 5):
        wg = gc(dna[i:i+GC_WINDOW_SIZE])
        if wg < GC_WINDOW_MIN or wg > GC_WINDOW_MAX:
            win_viol += 1
    pen += 10.0 * win_viol

    if cache_5p_dg is None:
        head = dna[:DG_5PRIME_WINDOW].replace('T', 'U')
        cache_5p_dg = dg(head, temp=37.0)
    if cache_5p_dg < DG_5PRIME_MIN:
        pen += 50.0 * (DG_5PRIME_MIN - cache_5p_dg)

    c = cai(dna)
    if c < CAI_MIN:
        pen += 200.0 * (CAI_MIN - c)

    E = pen - c
    return E, pen, c, cache_5p_dg


def solve(protein: str,
          max_iters: int = 30_000,
          T_init: float = 1.0,
          T_final: float = 0.001,
          seed: int = 42,
          verbose: bool = True):
    """Simulated-annealing search; returns best valid sequence found."""
    rng = random.Random(seed)
    seq = [AA_TO_CODONS[aa][0] for aa in protein + '*']  # greedy init: most-frequent
    dna = ''.join(seq)

    cur_E, cur_pen, cur_cai, cur_dg5 = energy(dna)
    best_valid_dna, best_valid_cai = None, -1.0

    for it in range(max_iters):
        T = T_init * (T_final / T_init) ** (it / max_iters)

        pos = rng.randrange(len(seq))
        aa = CODON_TO_AA[seq[pos]]
        alts = [c for c in AA_TO_CODONS[aa] if c != seq[pos]]
        if not alts:
            continue
        old_codon = seq[pos]
        seq[pos] = rng.choice(alts)
        new_dna = ''.join(seq)

        new_dg5 = None if pos < DG_5PRIME_WINDOW // 3 else cur_dg5
        new_E, new_pen, new_cai, new_dg5 = energy(new_dna, cache_5p_dg=new_dg5)
        dE = new_E - cur_E

        if dE < 0 or rng.random() < math.exp(-dE / T):
            cur_E, cur_pen, cur_cai, cur_dg5, dna = new_E, new_pen, new_cai, new_dg5, new_dna
            if cur_pen == 0 and cur_cai > best_valid_cai:
                best_valid_cai = cur_cai
                best_valid_dna = dna
                if verbose:
                    print(f"  iter {it:6d}  T={T:.4f}  CAI={cur_cai:.4f}  (best valid)")
        else:
            seq[pos] = old_codon

    return best_valid_dna, best_valid_cai


if __name__ == '__main__':
    # 100-aa toy protein for a quick run
    test_protein = "MKLVAILGSTDKFGRPVAITLNDQEYWHCSARLMNGTILDFKEAVPQRHWYIGSCMNDKLAVTRPEQHWYIGSCMNDKLAVTRPEQHWYIGSCMNDKLAV"
    print(f"Protein length: {len(test_protein)} aa")
    best, score = solve(test_protein, max_iters=15_000, verbose=True)
    if best:
        print(f"\nBest valid CAI: {score:.4f}")
        print(f"Best DNA: {best[:60]}...")
    else:
        print("No valid solution found")
